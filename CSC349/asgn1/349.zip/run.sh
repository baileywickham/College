#!/bin/sh

python3 algo.py "$1"
