#!/bin/sh

python3 graph.py "$1"
