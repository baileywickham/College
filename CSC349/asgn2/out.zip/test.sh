python graph.py in1.txt > tmp
diff tmp out1.txt

python graph.py in2.txt > tmp
diff tmp out2.txt

python graph.py in3.txt > tmp
diff tmp out3.tx
